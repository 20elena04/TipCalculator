// SplitBillPage
import 'package:flutter/material.dart';

class SplitBillPage extends StatefulWidget {
  @override
  _SplitBillPageState createState() => _SplitBillPageState();
}

class _SplitBillPageState extends State<SplitBillPage> {
  int numberOfPeople = 1;
  double splitAmount = 0.0;
  String totalAmount = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Split Bill'),
        backgroundColor: Colors.indigo,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            TextField(
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              onChanged: (value) {
                totalAmount = value;
              },
              decoration: InputDecoration(
                labelText: 'Enter Total Amount',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20.0),
            TextField(
              keyboardType: TextInputType.number,
              onChanged: (value) {
                setState(() {
                  numberOfPeople = int.tryParse(value) ?? 1;
                });
              },
              decoration: InputDecoration(
                labelText: 'Enter Number of People',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                _calculateSplitAmount();
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.indigo,
                onPrimary: Colors.white,
                padding: EdgeInsets.all(16.0),
              ),
              child: Text('Calculate'),
            ),
            SizedBox(height: 20.0),
            Text('Split Amount: \$${splitAmount.toStringAsFixed(2)}', style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }

  void _calculateSplitAmount() {
    double total = double.tryParse(totalAmount) ?? 0.0;

    setState(() {
      splitAmount = total / numberOfPeople;
    });
  }
}
