// CalculatorPage
import 'package:flutter/material.dart';
import 'split_bill_page.dart';

class CalculatorPage extends StatefulWidget {
  @override
  _CalculatorPageState createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  double billAmount = 0.0;
  String selectedCurrency = '\$';
  double tipPercentage = 15;
  double tipAmount = 0.0;
  double totalAmount = 0.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tip Calculator'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'Enter Bill Amount',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                setState(() {
                  billAmount = double.tryParse(value) ?? 0.0;
                });
              },
            ),
            SizedBox(height: 20),
            DropdownButton<String>(
              value: selectedCurrency,
              onChanged: (String? value) {
                setState(() {
                  selectedCurrency = value ?? '\$';
                });
              },
              items: <String>['\$', 'LBP'].map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text('Tip Percentage:'),
                DropdownButton<double>(
                  value: tipPercentage,
                  onChanged: (double? value) {
                    setState(() {
                      tipPercentage = value ?? 0.0;
                    });
                  },
                  items: <double>[5, 10, 15, 20, 25, 30].map((double value) {
                    return DropdownMenuItem<double>(
                      value: value,
                      child: Text('$value %'),
                    );
                  }).toList(),
                ),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  tipAmount = (billAmount * tipPercentage) / 100;
                  totalAmount = billAmount + tipAmount;
                });
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.teal,
                onPrimary: Colors.white,
                padding: EdgeInsets.all(16.0),
              ),
              child: Text('Generate'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SplitBillPage()),
                );
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.indigo,
                onPrimary: Colors.white,
                padding: EdgeInsets.all(16.0),
              ),
              child: Text('Split Bill'),
            ),
            SizedBox(height: 20),
            if (tipAmount != 0.0)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Bill Amount: \$${billAmount.toStringAsFixed(2)}'),
                  Text('Tip Percentage: ${tipPercentage.toStringAsFixed(2)}%'),
                  Text('Tip Amount: \$${tipAmount.toStringAsFixed(2)}'),
                  Divider(),
                  Text('Total Amount: \$${totalAmount.toStringAsFixed(2)}'),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
